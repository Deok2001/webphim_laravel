

<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:20px">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <table class="table " id="tablemovie">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Movie</th>
                    <th scope="col">Image</th>
                    <th scope="col">Episode</th>
                    <th scope="col">Link </th>
                    <th scope="col">Active/Inactive</th>
                    <th scope="col">Manage</th>
                  </tr>
                </thead>
                <tbody class="order_position">
                    <?php $__currentLoopData = $list_episode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($key); ?></th>
                            <td><?php echo e($value->movie->title); ?></td>
                            <td><img style="width:80%" src="<?php echo e(asset('uploads/movie/'.$value->movie->image)); ?>"></td>
                            <td><?php echo e($value->episode); ?></td>
                             <td><?php echo e($value->link); ?></td>
                            <td>
                                <?php if($value->status): ?>
                                    Hiển thị
                                <?php else: ?>
                                    Không hiển thị
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo Form::open(['route'=>['episode.destroy',$value->id],'method'=>'DELETE', 'onsubmit'=>'return confirm("Bạn có chắc muốn xóa không?")']); ?>

                                    <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>

                                <?php echo Form::close(); ?>

                                <a href="<?php echo e(route('episode.edit',$value->id)); ?>" class="btn btn-warning">Sửa</a>
                            </td>
                        </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\Laravel\webphim_laravel\resources\views/admincp/episode/index.blade.php ENDPATH**/ ?>