

<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:20px">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card" style="margin-bottom:15px">
                
                
                <style type="text/css">
                    .alert-danger{
                        background-color: #fe1302;
                        font-weight: 500;
                    }
                </style>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(!isset($movie)): ?>
                    <?php echo Form::open(['route'=>'movie.store','method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                        <?php echo Form::open(['route'=>['movie.update', $movie->id],'method'=>'PUT', 'enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('title', 'Title', []); ?>

                            <?php echo Form::text('title', isset($movie) ? $movie->title : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....', 'id'=>'slug', 'onkeyup'=>'ChangeToSlug()']); ?>

                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('slug', 'Slug', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::text('slug', isset($movie) ? $movie->slug : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....', 'id'=>'convert_slug']); ?>

                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('episode', 'Episode', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::text('episode', isset($movie) ? $movie->episode : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....', 'id'=>'episode']); ?>

                            <?php $__errorArgs = ['episode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('movie_duration', 'Movie Duration', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::text('movie_duration', isset($movie) ? $movie->movie_duration : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....' ]); ?>

                            <?php $__errorArgs = ['movie_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('trailer', 'Trailer', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::text('trailer', isset($movie) ? $movie->trailer : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....' ]); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Name English', 'Name Enghlish', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::text('name_eng', isset($movie) ? $movie->name_eng : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....', 'id'=>'name_eng']); ?>

                            <?php $__errorArgs = ['name_eng'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group" style="display: table-caption;">
                            <?php echo Form::label('Image', 'Image', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::file('image', ['style'=>'margin-top: 12px','class'=>'form-control-file']); ?>

                            <?php if(isset($movie)): ?>
                                <img style="width:50%" src="<?php echo e(asset('uploads/movie/'.$movie->image)); ?>">
                            <?php endif; ?>
                            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group" >
                            <?php echo Form::label('description', 'Description', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::textarea('description', isset($movie) ? $movie->description : '',['style'=>'resize:none; margin-top: 12px','class'=>'form-control','placeholder' => '....', 'id'=>'description']); ?>

                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group" >
                            <?php echo Form::label('tags', 'Tags ', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::textarea('tags', isset($movie) ? $movie->tags : '',['style'=>'resize:none; margin-top: 12px','class'=>'form-control','placeholder' => '....']); ?>

                            <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('active', 'Active', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('status', ['1'=>'Hiển thị', '0'=>'Không'], isset($movie) ? $movie->status : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control', 'placeholder' => '--Kích hoạt--' ]); ?>

                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('subtitle', 'Subtitle', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('subtitle', ['0'=>'Phụ đề', '1'=>'Thuyết minh'], isset($movie) ? $movie->subtitle : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control', 'placeholder' => '--Subtitle--' ]); ?>

                            <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('resolution', 'Resolution', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('resolution', ['0'=>'HD', '1'=>'SD', '2'=>'HDCam', '3'=>'Cam', '4'=>'FullHD', '5'=>'Trailer'], isset($movie) ? $movie->resolution : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control', 'placeholder' => '--Độ phân giải--' ]); ?>

                            <?php $__errorArgs = ['resolution'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('category', 'Category', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('category_id', $category, isset($movie) ? $movie->category_id : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control',  'placeholder' => '--Danh mục phim--']); ?>

                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('format', 'Format', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('format', ['phimle'=>'Phim lẻ', 'phimbo'=>'Phim bộ'], isset($movie) ? $movie->format : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control', 'placeholder' => '--Format--']); ?>

                            <?php $__errorArgs = ['format'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('genre', 'Genre', ['style'=>'margin-top: 12px']); ?><br>
                            
                            <?php $__currentLoopData = $list_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset ($movie)): ?>
                                <?php echo Form::checkbox('genre[]',$gen->id, isset($movie_genre) &&  $movie_genre->contains($gen->id) ? true : false); ?>

                                <?php else: ?>
                                <?php echo Form::checkbox('genre[]', $gen->id, '' ); ?>

                                <?php endif; ?>
                                    <?php echo Form::label('genre', $gen->title); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('country', 'Country', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('country_id', $country, isset($movie) ? $movie->country_id : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control', 'placeholder' => '--Quốc gia--']); ?>

                            <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('Hot', 'Hot', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('phim_hot', ['1'=>'Có', '0'=>'Không'], isset($movie) ? $movie->phim_hot : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control', 'placeholder' => '--Hot--']); ?>

                            <?php $__errorArgs = ['phim_hot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if(!isset($movie)): ?>
                            <?php echo Form::submit('Thêm dữ liệu', ['style'=>'margin-top: 12px','class'=>'btn btn-success']); ?>

                        <?php else: ?>
                            <?php echo Form::submit('Cập nhật', ['style'=>'margin-top: 12px','class'=>'btn btn-warning']); ?>

                        <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\Laravel\webphim_laravel\resources\views/admincp/movie/form.blade.php ENDPATH**/ ?>