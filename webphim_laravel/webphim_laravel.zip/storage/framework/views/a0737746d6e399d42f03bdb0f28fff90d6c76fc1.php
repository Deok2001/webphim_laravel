
<?php $__env->startSection('content'); ?>
<div class="row container" id="wrapper">
    <div class="halim-panel-filter">
       <div class="panel-heading">
          <div class="row">
             <div class="col-xs-6">
                <div class="yoast_breadcrumb hidden-xs"><span><span><a href="">Phim hay</a> » <span><a href="<?php echo e(route('country',[$movie->country->slug])); ?>"><?php echo e($movie->country->title); ?></a> » <span class="breadcrumb_last" aria-current="page"><?php echo e($movie->title); ?></span></span></span></span></div>
             </div>
          </div>
       </div>
       <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
          <div class="ajax"></div>
       </div>
    </div>
    <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
       <section id="content" class="test">
          <div class="clearfix wrap-content">
             <style type="text/css">
            .iframe_movie iframe {
               width: 100%;
               height: 500px;
            }
            </style>
            <div class="iframe_movie">
               <?php echo $episode->link; ?>

            </div> 
            
             
             
          
             <div class="clearfix"></div>
             <div class="clearfix"></div>
             <div class="title-block">
                <a href="javascript:;" data-toggle="tooltip" title="Add to bookmark">
                   <div id="bookmark" class="bookmark-img-animation primary_ribbon" data-id="37976">
                      <div class="halim-pulse-ring"></div>
                   </div>
                </a>
                <div class="title-wrapper-xem full">
                   <h1 class="entry-title"><a href="" title="<?php echo e($movie->title); ?>" class="tl"><?php echo e($movie->title); ?></a></h1>
                </div>
             </div>
             <div class="entry-content htmlwrap clearfix collapse" id="expand-post-content">
                <article id="post-37976" class="item-content post-37976"></article>
             </div>
             <div class="clearfix"></div>
             <div class="text-center">
                <div id="halim-ajax-list-server"></div>
             </div>
             <div id="halim-list-server">
                <ul class="nav nav-tabs" role="tablist">
                     <?php if($movie->resolution==0): ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i> HD</a></li>
                     <?php elseif($movie->resolution==1): ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i> SD</a></li>
                     <?php elseif($movie->resolution==2): ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i> HDCam</a></li>
                     <?php elseif($movie->resolution==3): ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i> Cam</a></li>
                     <?php elseif($movie->resolution==4): ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i> FullHD</a></li>
                     <?php else: ?>
                           <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i> Trailer</a></li>
                     <?php endif; ?>
                     <?php if($movie->subtitle==0): ?>      
                        <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i> Phụ đề</a></li>      
                     <?php else: ?>     
                        <li role="presentation" class="active server-1"><a href="#server-0" aria-controls="server-0" role="tab" data-toggle="tab"><i class="hl-server"></i> Thuyết minh</a></li>
                           
                     <?php endif; ?>
                   
                   
                </ul>
                
                <div class="tab-content">
                   <div role="tabpanel" class="tab-pane active server-1" id="server-0">
                      <div class="halim-server">
                         <ul class="halim-list-eps">
                           <?php $__currentLoopData = $movie->episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ep_movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('xem-phim/'.$movie->slug.'/tap-'.$ep_movie->episode)); ?>">
                              <li class="halim-episode">
                                 <span class="halim-btn halim-btn-2 <?php echo e($ep==$ep_movie->episode ? 'active' : ''); ?> halim-info-1-1 box-shadow" data-post-id="37976" data-server="1" data-episode="1" data-position="first" data-embed="0" data-title="Xem phim <?php echo e($ep_movie->title); ?> - Tập <?php echo e($ep_movie->episode); ?> - <?php echo e($ep_movie->name_eng); ?> - <?php echo e($ep_movie->subtitle); ?>" data-h1="<?php echo e($ep_movie->title); ?> - tập <?php echo e($ep_movie->episode); ?>"><?php echo e($ep_movie->episode); ?></span>
                              </li>
                           </a>
                               
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                         </ul>
                         <div class="clearfix"></div>
                      </div>
                   </div>
                </div>
             </div>
             <div class="clearfix"></div>
             <div class="htmlwrap clearfix">
                <div id="lightout"></div>
             </div>
       </section>
       <section class="related-movies">
       <div id="halim_related_movies-2xx" class="wrap-slider">
       <div class="section-bar clearfix">
       <h3 class="section-title"><span>CÓ THỂ BẠN MUỐN XEM</span></h3>
       </div>
       <div id="halim_related_movies-2" class="owl-carousel owl-theme related-film">
         <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($mov->resolution!=5): ?>
            <article class="thumb grid-item post-38494">
               <div class="halim-item">
               <a class="halim-thumb" href="<?php echo e(route('movie',$mov->slug)); ?>" title="<?php echo e($mov->title); ?>">
               <figure><img class="lazy img-responsive" src="<?php echo e(asset('uploads/movie/'.$mov->image)); ?>" alt="<?php echo e($mov->title); ?>" title="<?php echo e($mov->title); ?>"></figure>
               <span class="status">
                  <?php if($mov->resolution==0): ?>
                        HD
                  <?php elseif($mov->resolution==1): ?>
                        SD
                  <?php elseif($mov->resolution==2): ?>
                        HDCam
                  <?php elseif($mov->resolution==3): ?>
                        Cam
                  <?php elseif($mov->resolution==4): ?>
                        FullHD
                  <?php else: ?>
                        Trailer
                  <?php endif; ?>   
               </span>
               <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>
                  <?php if($mov->subtitle==0): ?>
                        Phụ đề
                  <?php else: ?>
                        Thuyết minh
                  <?php endif; ?>
               </span> 
               
               <div class="icon_overlay"></div>
               <div class="halim-post-title-box">
               <div class="halim-post-title ">
               <p class="entry-title"><?php echo e($mov->title); ?></p>
               <p class="original_title"><?php echo e($mov->name_eng); ?></p>
               </div>
               </div>
               </a>
               </div>
            </article>
            <?php endif; ?>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
       </div>
       <script>
          jQuery(document).ready(function($) {				
          var owl = $('#halim_related_movies-2');
          owl.owlCarousel({loop: true,margin: 4,autoplay: true,autoplayTimeout: 4000,autoplayHoverPause: true,nav: true,navText: ['<i class="hl-down-open rotate-left"></i>', '<i class="hl-down-open rotate-right"></i>'],responsiveClass: true,responsive: {0: {items:2},480: {items:3}, 600: {items:4},1000: {items: 4}}})});
       </script>
       </div>
       </section>
    </main>
    
    <?php echo $__env->make('pages.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\Laravel\webphim_laravel\resources\views/pages/watch.blade.php ENDPATH**/ ?>