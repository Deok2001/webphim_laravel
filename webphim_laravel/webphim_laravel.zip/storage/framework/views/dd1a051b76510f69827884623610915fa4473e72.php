

<?php $__env->startSection('content'); ?>

<table class="table" id="tablemovie" style="margin-top:8px">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Title</th>
        <th scope="col">Slug</th>
        <th scope="col">Description</th>
        <th scope="col">Active/Inactive</th>
        <th scope="col">Manage</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($key); ?></th>
            <td><?php echo e($value->title); ?></td>
            <td><?php echo e($value->slug); ?></td>
            <td><?php echo e($value->description); ?></td>
            <td>
                <?php if($value->status): ?>
                    Hiển thị
                <?php else: ?>
                    Không hiển thị
                <?php endif; ?>
            </td>
            <td>
                <?php echo Form::open(['route'=>['country.destroy',$value->id],'method'=>'DELETE', 'onsubmit'=>'return confirm("Bạn có chắc muốn xóa không?")']); ?>

                    <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>

                <?php echo Form::close(); ?>

                <a href="<?php echo e(route('country.edit',$value->id)); ?>" class="btn btn-warning">Sửa</a>
            </td>
          </tr>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\Laravel\webphim_laravel\resources\views/admincp/country/index.blade.php ENDPATH**/ ?>