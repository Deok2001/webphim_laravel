

<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:20px">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card" style="margin-bottom:15px">
                
                <div class="card-header"><?php echo e(__('Quản lý tập phim')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(!isset($episode)): ?>
                    <?php echo Form::open(['route'=>'episode.store','method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route'=>['episode.update', $episode->id],'method'=>'PUT', 'enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                        
                        <div class="form-group">
                            <?php echo Form::label('movie_title', 'Movie', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::text('movie_title',  isset($movie) ? $movie->title : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control', 'readonly']); ?>

                            <?php echo Form::hidden('movie_id',  isset($movie) ? $movie->id : '', []); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('link', 'Link Movie', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::text('link', isset($episode) ? $episode->link : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....']); ?>

                        </div>
                        <?php if(isset($episode)): ?>
                            <div class="form-group">
                                <?php echo Form::label('episode', 'Episode Movie', ['style'=>'margin-top: 12px']); ?>

                                
                                <?php echo Form::text('episode', isset($episode) ? $episode->episode : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....', isset($episode) ? 'readonly' : '']); ?>

                            </div>
                        <?php else: ?> 
                        <div class="form-group">
                            <?php echo Form::label('episode', 'Episode Movie', ['style'=>'margin-top: 12px']); ?>

                            
                            <?php echo Form::selectRange('episode', 1,  $movie->episode, $movie->episode ,['style'=>'margin-top: 12px','class'=>'form-control']); ?>

                        </div>
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <?php echo Form::label('active', 'Active', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('status', ['1'=>'Hiển thị', '0'=>'Không'], isset($episode) ? $episode->status : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control' ]); ?>

                        </div>

                        <?php if(!isset($episode)): ?>
                            <?php echo Form::submit('Thêm dữ liệu', ['style'=>'margin-top: 12px','class'=>'btn btn-success']); ?>

                        <?php else: ?>
                            <?php echo Form::submit('Cập nhật', ['style'=>'margin-top: 12px','class'=>'btn btn-warning']); ?>

                        <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
        
        <div class="col-md-12">
            <table class="table " id="tablemovie">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Movie</th>
                    <th scope="col">Image</th>
                    <th scope="col">Episode</th>
                    <th scope="col">Link </th>
                    <th scope="col">Active/Inactive</th>
                    <th scope="col">Manage</th>
                  </tr>
                </thead>
                <tbody class="order_position">
                    <?php $__currentLoopData = $list_episode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($key); ?></th>
                            <td><?php echo e($value->movie->title); ?></td>
                            <td><img style="width:80%" src="<?php echo e(asset('uploads/movie/'.$value->movie->image)); ?>"></td>
                            <td><?php echo e($value->episode); ?></td>
                             <td><?php echo e($value->link); ?></td>
                            <td>
                                <?php if($value->status): ?>
                                    Hiển thị
                                <?php else: ?>
                                    Không hiển thị
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo Form::open(['route'=>['episode.destroy',$value->id],'method'=>'DELETE', 'onsubmit'=>'return confirm("Bạn có chắc muốn xóa không?")']); ?>

                                    <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>

                                <?php echo Form::close(); ?>

                                <a href="<?php echo e(route('episode.edit',$value->id)); ?>" class="btn btn-warning">Sửa</a>
                            </td>
                        </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\Laravel\webphim_laravel\resources\views/admincp/episode/add_episode.blade.php ENDPATH**/ ?>