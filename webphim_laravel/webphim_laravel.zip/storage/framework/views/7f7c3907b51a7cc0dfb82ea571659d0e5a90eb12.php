

<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:20px">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card" style="margin-bottom:15px">
                
                
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(!isset($info)): ?>
                    <?php echo Form::open(['route'=>'info.store','method'=>'POST' , 'enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                        <?php echo Form::open(['route'=>['info.update', $info->id],'method'=>'PUT' , 'enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                        <div class="form-group">
                            <?php echo Form::label('title', 'Title', []); ?>

                            <?php echo Form::text('title', isset($info) ? $info->title : '',['style'=>'margin-top: 12px', 'class'=>'form-control  ',  'placeholder' => 'Nhập vào dữ liệu...', 'id'=>'slug', 'onkeyup'=>'ChangeToSlug()']); ?>

                            
                        </div>
                        <div class="form-group" style="display: table-caption;">
                            <?php echo Form::label('logo', 'Logo', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::file('logo', ['style'=>'margin-top: 12px','class'=>'form-control-file']); ?>

                            <?php if(isset($info)): ?>
                                <img style="width:50%" src="<?php echo e(asset('uploads/logo/'.$info->logo)); ?>">
                            <?php endif; ?>
                            
                        </div>
                        
                        <div class="form-group" >
                            <?php echo Form::label('description', 'Description', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::textarea('description', isset($info) ? $info->description : '',['style'=>'resize:none; margin-top: 12px','class'=>'form-control', 'placeholder' => 'Nhập vào dữ liệu...', 'id'=>'description']); ?>

                            
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('copyright', 'Copyright', []); ?>

                            <?php echo Form::text('copyright', isset($info) ? $info->copyright : '',['style'=>'margin-top: 12px', 'class'=>'form-control  ',  'placeholder' => 'Nhập vào dữ liệu...', 'id'=>'slug', 'onkeyup'=>'ChangeToSlug()']); ?>

                            
                        </div>
                        <div class="form-group">
                            <?php echo Form::label('active', 'Active', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('status', ['1'=>'Hiển thị', '0'=>'Không'], isset($info) ? $info->status : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control', 'placeholder' => '--Kích hoạt--']); ?>

                            
                        </div>
                        <?php if(!isset($info)): ?>
                            <?php echo Form::submit('Thêm dữ liệu', ['class'=>'btn btn-success']); ?>

                        <?php else: ?>
                            <?php echo Form::submit('Cập nhật', ['class'=>'btn btn-warning']); ?>

                        <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\Laravel\webphim_laravel\resources\views/admincp/info/form.blade.php ENDPATH**/ ?>