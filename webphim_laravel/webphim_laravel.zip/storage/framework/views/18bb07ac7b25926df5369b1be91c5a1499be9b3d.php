

<?php $__env->startSection('content'); ?>




<div class="container-fluid" >
    <div class="row justify-content-center">
        <div class="col-md-12">
            
            <table class="table table-responsive" style="display: block" id="tablemovie" >
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Add_Ep</th>
                    <th scope="col">Episode</th>
                    <th scope="col">Slug</th>
                    <th scope="col">Trailer</th>
                    <th scope="col">Duration</th>
                    <th scope="col">English</th>
                    <th scope="col">Image</th>
                    <th scope="col">Genre</th>
                    <th scope="col">Format</th>
                    
                    
                    <th scope="col">Category</th>
                    <th scope="col">Country</th>
                    <th scope="col">Hot</th>
                    <th scope="col">Subtitle</th>
                    <th scope="col">Resolution</th>
                    <th scope="col">View</th>
                    <th scope="col">Year</th>
                    <th scope="col">Season</th>
                    <th scope="col">Active/Inactive</th>
                    <th scope="col">Created_at</th>
                    <th scope="col">Updated_at</th>
                    <th scope="col">Manage</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($key); ?></th>
                        <td><?php echo e($value->title); ?></td>
                        <td>
                            <a href="<?php echo e(route('add-episode',[$value->id])); ?>" class="btn btn-success btn-sm">Thêm tập phim</a>
                            <?php $__currentLoopData = $value->episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $epis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="show_video" 
                                    data-movie_video_id="<?php echo e($epis->movie_id); ?>" 
                                    data-video_episode="<?php echo e($epis->episode); ?>"  
                                    style="color: #fff; cursor: pointer;"> 

                                    <span class="badge badge-dark"><?php echo e($epis->episode); ?></span>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </td>
                        <td>
                            <?php if($value->format == 'phimle'): ?>
                                <?php echo e($value->episodes_count); ?>/<?php echo e($value->episode); ?> Bản
                            <?php elseif($value->format == 'phimbo'): ?>
                                <?php echo e($value->episodes_count); ?>/<?php echo e($value->episode); ?> Tập
                            <?php else: ?>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($value->slug); ?></td>
                        <td><?php echo e($value->trailer); ?></td>
                        <td><?php echo e($value->movie_duration); ?></td>
                        <td><?php echo e($value->name_eng); ?></td>
                        <td>
                            <img style="width:60%" src="<?php echo e(asset('uploads/movie/'.$value->image)); ?>">
                            <input type="file"  data-movie_id="<?php echo e($value->id); ?>" id="file-<?php echo e($value->id); ?>" class="form-control-file file_image" accept="image/*">
                            <span id="success_image"></span>
                        </td>
                        <td>
                            <?php $__currentLoopData = $value->movie_genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-dark"><?php echo e($gen->title); ?></span>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            
                            <select id="<?php echo e($value->id); ?>" class="select-format">
                                <?php if($value->format== 'phimbo'): ?>
                                <option value="phimle">Phim lẻ</option>
                                <option selected value="phimbo">Phim bộ</option>
                                <?php else: ?>
                                <option selected value="phimle">Phim lẻ</option>
                                <option  value="phimbo">Phim bộ</option>
                            <?php endif; ?>
                            </select>
                        </td>
                        
                        
                        <td>
                            
                            <?php echo Form::select('category_id', $category, isset($value) ? $value->category->id : '', [ 'class' => 'select-category', 'id'=> $value->id ,'placeholder'=> '--Category--']); ?>

                        </td>
                        <td>
                            
                            <?php echo Form::select('country_id', $country, isset($value) ? $value->country->id : '', [ 'class' => 'select-country', 'id'=> $value->id ,'placeholder'=> '--Country--']); ?>

                        </td>
                        <td>
                            
                            <select id="<?php echo e($value->id); ?>" class="select-hot">
                                <?php if($value->phim_hot==0): ?>
                                <option value="1">Hot</option>
                                <option selected value="0">Không</option>
                                <?php else: ?>
                                <option selected value="1">Hot</option>
                                <option  value="0">Không</option>
                            <?php endif; ?>
                            </select>
                        </td>
                        <td>
                            
                            <select id="<?php echo e($value->id); ?>" class="select-subtitle">
                                <?php if($value->subtitle==0): ?>
                                <option value="1">Thuyết minh</option>
                                <option selected value="0">Phụ đề</option>
                                <?php else: ?>
                                <option selected value="1">Thuyết minh</option>
                                <option  value="0">Phụ đề</option>
                                <?php endif; ?>
                            </select>    
                        </td>
                        <td>
                            

                            <?php
                                $options = array('0'=>'HD', '1'=>'SD', '2'=>'HDCam', '3'=>'Cam', '4'=>'FullHD', '5'=>'Trailer');
                            ?>
                            <select id="<?php echo e($value->id); ?>" class="select-resolution">
                                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $resol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($value->resolution==$key ? 'selected' : ''); ?> value="<?php echo e($key); ?>"><?php echo e($resol); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </td>
                        <td>
                            <?php echo Form::select('top_view', ['0'=>'Ngày', '1'=>'Tuần', '2'=>'Tháng'], isset($value->top_view) ? $value->top_view : '', [ 'class' => 'select-topview', 'id'=> $value->id , 'placeholder'=> '--Views--']); ?>

                        </td>
                        <td>
                            <form method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo Form::selectYear('year',2000,2023, isset($value->year) ? $value->year : '' , ['class' => 'select-year', 'id' => $value->id, 'placeholder'=> '--Năm phim--']); ?>

                            </form>
                        </td>
                        <td>
                            <form method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo Form::selectRange('season',0, 20, isset($value->season) ? $value->season : '' , ['class' => 'select-season', 'id' => $value->id, 'placeholder'=> '--Season--']); ?>

                            </form>
                        </td>
                        <td>
                            
                            <select id="<?php echo e($value->id); ?>" class="select-status">
                                <?php if($value->status==0): ?>
                                <option value="1">Hiển thị</option>
                                <option selected value="0">Không</option>
                                <?php else: ?>
                                <option selected value="1">Hiển thị</option>
                                <option  value="0">Không</option>
                            <?php endif; ?>
                            </select>
                        </td>
                        <td><?php echo e($value->created_at); ?></td>
                        <td><?php echo e($value->updated_at); ?></td>
                        <td>
                            <?php echo Form::open(['route'=>['movie.destroy',$value->id],'method'=>'DELETE', 'onsubmit'=>'return confirm("Bạn có chắc muốn xóa không?")']); ?>

                                <?php echo Form::submit('Xóa', ['class'=>'btn btn-danger']); ?>

                            <?php echo Form::close(); ?>

                            <a href="<?php echo e(route('movie.edit',$value->id)); ?>" class="btn btn-warning">Sửa</a>
                        </td>
                      </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\Laravel\webphim_laravel\resources\views/admincp/movie/index.blade.php ENDPATH**/ ?>