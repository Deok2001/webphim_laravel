
<?php $__env->startSection('content'); ?>   
<div class="row container" id="wrapper">
    <div class="halim-panel-filter">
       <div id="ajax-filter" class="panel-collapse collapse" aria-expanded="true" role="menu">
          <div class="ajax"></div>
       </div>
    </div>
    
    <div id="halim_related_movies-2xx" class="wrap-slider">
      <div class="section-bar clearfix">
         <h3 class="section-title"><span>Phim Hot</span></h3>
      </div>
      <div id="halim_related_movies-2" class="owl-carousel owl-theme related-film">
         <?php $__currentLoopData = $phimhot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php if($hot->resolution!=5): ?>
         <article class="thumb grid-item post-38498">
            <div class="halim-item">
               <a class="halim-thumb" href="<?php echo e(route('movie',$hot->slug)); ?>" title="<?php echo e($hot->title); ?>">
                  <figure><img class="lazy img-responsive" src="<?php echo e(asset('uploads/movie/'.$hot->image)); ?>" alt="Đại Thánh Vô Song" title="<?php echo e($hot->title); ?>"></figure>
                  <span class="status">
                     <?php if($hot->resolution==0): ?>
                        HD
                     <?php elseif($hot->resolution==1): ?>
                        SD
                     <?php elseif($hot->resolution==2): ?>
                        HDCam
                     <?php elseif($hot->resolution==3): ?>
                        Cam
                     <?php elseif($hot->resolution==4): ?>
                        FullHD
                     <?php else: ?>
                        Trailer
                     <?php endif; ?>   
                  </span>
                  <?php if($hot->resolution!=5): ?>
                     <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>
                        <?php if($hot->subtitle==0): ?>
                              Phụ đề
                              <?php if($hot->season!=0): ?>
                                 - Season <?php echo e($hot->season); ?>

                              <?php endif; ?>
                        <?php else: ?>
                              Thuyết minh
                              <?php if($hot->season!=0): ?>
                                 - Season <?php echo e($hot->season); ?>

                              <?php endif; ?>
                        <?php endif; ?>
                     </span>
                     <?php endif; ?>
                  <div class="icon_overlay"></div>
                  <div class="halim-post-title-box">
                     <?php if($hot->resolution!=5): ?>
                        <?php if($hot->format == 'phimbo'): ?>
                           <span class="episode">
                              <?php echo e($hot->episodes_count); ?>/<?php echo e($hot->episode); ?> Tập
                           </span>
                           
                        <?php endif; ?>
                     
                     <?php endif; ?>
                     <div class="halim-post-title ">
                        
                        <p class="entry-title"><?php echo e($hot->title); ?></p>
                        <p class="original_title"><?php echo e($hot->name_eng); ?></p>
                     </div>
                  </div>
               </a>
            </div>
         </article>
         <?php endif; ?>
         
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
           
        
      </div>
      <script>
         jQuery(document).ready(function($) {				
         var owl = $('#halim_related_movies-2');
         owl.owlCarousel({loop: true,margin: 4,autoplay: true,autoplayTimeout: 4000,autoplayHoverPause: true,nav: true,navText: ['<i class="hl-down-open rotate-left"></i>', '<i class="hl-down-open rotate-right"></i>'],responsiveClass: true,responsive: {0: {items:2},480: {items:3}, 600: {items:4},1000: {items: 4}}})});
      </script>
   </div>
    <main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
      <?php $__currentLoopData = $category_home; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate_home): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <section id="halim-advanced-widget-2">
         <div class="section-heading">
            <a href="<?php echo e(route('category', $cate_home->slug)); ?>" title="<?php echo e($cate_home->title); ?>">
            <span class="h-text"><?php echo e($cate_home->title); ?></span>
            </a>
         </div>
         <div id="halim-advanced-widget-2-ajax-box" class="halim_box">
         <?php $__currentLoopData = $cate_home->movie->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php if($mov->resolution!=5): ?>
           <article class="col-md-3 col-sm-3 col-xs-6 thumb grid-item post-37606">
            <div class="halim-item">
               <a class="halim-thumb" href="<?php echo e(route('movie',$mov->slug)); ?>">
                  <figure><img class="lazy img-responsive" src="<?php echo e(asset('uploads/movie/'.$mov->image)); ?>" alt="<?php echo e($mov->title); ?>" title="<?php echo e($mov->title); ?>"></figure>
                  <span class="status">
                         <?php if($mov->resolution==0): ?>
                             HD
                         <?php elseif($mov->resolution==1): ?>
                             SD
                         <?php elseif($mov->resolution==2): ?>
                             HDCam
                         <?php elseif($mov->resolution==3): ?>
                             Cam
                         <?php elseif($mov->resolution==4): ?>
                             FullHD
                         <?php else: ?>
                             Trailer
                         <?php endif; ?>   
                  </span>
                  <?php if($mov->resolution!=5): ?>
                  <span class="episode"><i class="fa fa-play" aria-hidden="true"></i>
                     <?php if($mov->subtitle==0): ?>
                           Phụ đề
                           <?php if($mov->season!=0): ?>
                              - Season <?php echo e($mov->season); ?>

                           <?php endif; ?>
                     <?php else: ?>
                           Thuyết minh
                           <?php if($mov->season!=0): ?>
                              - Season <?php echo e($mov->season); ?>

                           <?php endif; ?>
                     <?php endif; ?>
                  </span>
                  <?php endif; ?>
                  <div class="icon_overlay"></div>
                  <div class="halim-post-title-box">
                     <?php if($mov->resolution!=5): ?>
                        <?php if($mov->format == 'phimbo'): ?>
                              <span class="episode">
                                 <?php echo e($mov->episodes_count); ?>/<?php echo e($mov->episode); ?> Tập
                              </span>
                              
                           <?php endif; ?>
                     <?php endif; ?>
                     <div class="halim-post-title ">
                        <p class="entry-title"><?php echo e($mov->title); ?></p>
                        <p class="original_title"><?php echo e($mov->name_eng); ?></p>
                     </div>
                  </div>
               </a>
            </div>
         </article> 
         <?php endif; ?>
            

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
         </div>
      </section>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <div class="clearfix"></div>
       
    </main>
    
    <?php echo $__env->make('pages.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\Laravel\webphim_laravel\resources\views/pages/home.blade.php ENDPATH**/ ?>