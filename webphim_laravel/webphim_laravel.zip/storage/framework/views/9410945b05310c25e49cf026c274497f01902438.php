

<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:20px">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card" style="margin-bottom:15px">
                
                
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(!isset($episode)): ?>
                    <?php echo Form::open(['route'=>'episode.store','method'=>'POST', 'enctype'=>'multipart/form-data']); ?>

                    <?php else: ?>
                    <?php echo Form::open(['route'=>['episode.update', $episode->id],'method'=>'PUT', 'enctype'=>'multipart/form-data']); ?>

                    <?php endif; ?>
                        
                        <div class="form-group">
                            <?php echo Form::label('movie', 'Movie', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('movie_id', ['0'=>'Movie', 'Danh sách phim hiện có !'=>$list_movie] , isset($episode) ? $episode->movie_id : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control select-movie']); ?>

                        </div>
                        <div class="form-group">
                            <?php echo Form::label('link', 'Link Movie', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::text('link', isset($episode) ? $episode->link : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....']); ?>

                        </div>
                        <?php if(isset($episode)): ?>
                            <div class="form-group">
                                <?php echo Form::label('episode', 'Episode Movie', ['style'=>'margin-top: 12px']); ?>

                                
                                <?php echo Form::text('episode', isset($episode) ? $episode->episode : '',['style'=>'margin-top: 12px','class'=>'form-control', 'placeholder' => '....', isset($episode) ? 'readonly' : '']); ?>

                            </div>
                        <?php else: ?> 
                        <div class="form-group">
                            <?php echo Form::label('episode', 'Episode Movie', ['style'=>'margin-top: 12px']); ?>

                            <select class="form-control" name="episode" id="show_episode"></select>
                            
                        </div>
                        <?php endif; ?>
                        
                        <div class="form-group">
                            <?php echo Form::label('active', 'Active', ['style'=>'margin-top: 12px']); ?>

                            <?php echo Form::select('status', ['1'=>'Hiển thị', '0'=>'Không'], isset($episode) ? $episode->status : '', [ 'style'=>'margin-top: 12px', 'class' => 'form-control' ]); ?>

                        </div>

                        <?php if(!isset($episode)): ?>
                            <?php echo Form::submit('Thêm dữ liệu', ['style'=>'margin-top: 12px','class'=>'btn btn-success']); ?>

                        <?php else: ?>
                            <?php echo Form::submit('Cập nhật', ['style'=>'margin-top: 12px','class'=>'btn btn-warning']); ?>

                        <?php endif; ?>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\Laravel\webphim_laravel\resources\views/admincp/episode/form.blade.php ENDPATH**/ ?>